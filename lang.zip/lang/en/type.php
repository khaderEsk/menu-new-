<?php

return [
    'accountant' => 'accountant',
    'chef' => 'chef',
    'waiter' => 'waiter',
    'shisha' => 'shisha',
    'data entry' => 'data entry',
    'bar' => 'bar',
];
