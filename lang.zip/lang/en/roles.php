r<?php

return [

    'superAdmin' => 'Super admin',
    'citySuperAdmin' => 'City super admin',
    'dataEntry' => 'Data entry',
    'admin' => 'Admin',
    'employee' => 'Employee',
    'restaurantManager' => 'Restaurant Manager',

];
