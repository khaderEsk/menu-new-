<?php

return [
    'superAdmin' => 'سوبر أدمن',
    'citySuperAdmin' => 'سوبر أدمن تابع لمدينة',
    'dataEntry' => 'مدخل بيانات',
    'admin' => 'أدمن',
    'employee' => 'موظف',
    'restaurantManager' => 'مدير مطاعم',
];
