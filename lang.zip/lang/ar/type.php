<?php

return [
    'accountant' => 'محاسب',
    'chef' => 'شيف',
    'waiter' => 'نادل',
    'shisha' => 'موظف اراكيل',
    'data entry' => 'مدخل بيانات',
    'bar' => 'بار',
];
