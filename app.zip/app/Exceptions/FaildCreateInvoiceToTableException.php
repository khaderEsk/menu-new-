<?php

namespace App\Exceptions;

use Exception;

class FaildCreateInvoiceToTableException extends Exception
{
    //
}
